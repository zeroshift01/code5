package com.code5.fw.db;

import java.util.List;

/**
 * @author seuk
 *
 */
class SqlRunnerB {
	String key = null;
	String sqlOrg = null;
	String sql = null;
	List<String> param = null;
}
