package com.code5.biz.emp;

/**
 * @author seuk
 *
 */
public class Emp001 {

	/**
	 * @return
	 * @throws Exception
	 */
	public String emp00101() throws Exception {

		return "/WEB-INF/classes/com/code5/biz/emp/emp00101.jsp";
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public String emp00102() throws Exception {

		return emp00101();
	}

}
